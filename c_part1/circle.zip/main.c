#include <stdio.h>
#define pi 3.14
int main()
{
    printf("perimeter of circle with radius 6=%f \t",2*pi*6);
    printf("area of circle with radius 6=%f \n",pi*6*6);
    return 0;
}
